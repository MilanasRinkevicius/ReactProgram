namespace backend.Dtos
{
    public class TransactionShareDto
    {
        public int MemberId { get; set; }
        public decimal Share { get; set; }
    }
}